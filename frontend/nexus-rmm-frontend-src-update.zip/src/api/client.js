const BASE_URL = "http://localhost:8080";

/**
 * Minimal fetch wrapper used by every endpoint module in src/api/services.
 * Centralizing this means switching base URL, adding auth headers later,
 * or changing error handling only ever needs to happen in one place.
 */
export async function apiGet(path) {
  const response = await fetch(`${BASE_URL}${path}`);

  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (body?.message) message = body.message;
    } catch {
      // response wasn't JSON; keep the generic message
    }
    throw new ApiError(message, response.status);
  }

  return response.json();
}

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}
