import { EmptyState } from "./States";

/**
 * Generic table. columns: [{ key, header, render?, align?, mono? }].
 * `caption` is announced to screen readers only.
 */
export default function DataTable({ caption, columns, rows, getRowKey, emptyMessage }) {
  if (rows.length === 0) {
    return <EmptyState>{emptyMessage}</EmptyState>;
  }

  return (
    <div className="table-scroll">
      <table className="data-table">
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col" className={c.align === "right" ? "align-right" : undefined}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={getRowKey(row)}>
              {columns.map((c) => {
                const className =
                  [c.align === "right" ? "align-right" : "", c.mono ? "mono" : ""]
                    .filter(Boolean)
                    .join(" ") || undefined;
                return (
                  <td key={c.key} className={className}>
                    {c.render ? c.render(row) : row[c.key]}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
