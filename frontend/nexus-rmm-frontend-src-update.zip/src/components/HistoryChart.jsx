import { useMemo } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { EmptyState } from "./States";
import { formatRate } from "../utils/format";

/** A trend needs at least two real readings; fewer is "insufficient data", not a flat line. */
const MIN_REAL_POINTS = 2;
const DAY_MS = 86_400_000;
const CHART_HEIGHT = 220;

function formatValue(value, unit) {
  if (value === null || value === undefined) return "N/A";
  if (unit === "B/s") return formatRate(value);
  if (unit === "%") return `${Number(value).toFixed(1)}%`;
  return `${Number(value).toFixed(1)} ${unit}`;
}

/**
 * Line chart over real stored samples. Samples with no value (sensor
 * unavailable that cycle) stay in the series as null so the line shows a
 * genuine gap rather than being silently bridged.
 */
export default function HistoryChart({
  points,
  unit,
  domain,
  yAxisWidth,
  seriesName,
  emptyMessage = "Insufficient historical data. Continue monitoring to build history.",
}) {
  const { data, realCount, gapCount, spansDays } = useMemo(() => {
    const mapped = points.map((p) => ({ t: Date.parse(p.timestamp), value: p.value }));
    const real = mapped.filter((p) => p.value !== null && p.value !== undefined).length;
    const span = mapped.length > 1 ? mapped[mapped.length - 1].t - mapped[0].t : 0;
    return {
      data: mapped,
      realCount: real,
      gapCount: mapped.length - real,
      spansDays: span > DAY_MS,
    };
  }, [points]);

  if (realCount < MIN_REAL_POINTS) {
    return <EmptyState>{emptyMessage}</EmptyState>;
  }

  const tickFormat = (ms) =>
    spansDays
      ? new Date(ms).toLocaleDateString(undefined, { month: "short", day: "numeric" })
      : new Date(ms).toLocaleTimeString();

  return (
    <>
      <div style={{ width: "100%", height: CHART_HEIGHT }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" />
            <XAxis
              dataKey="t"
              type="number"
              scale="time"
              domain={["dataMin", "dataMax"]}
              tickFormatter={tickFormat}
              stroke="var(--color-text-muted)"
              fontSize={11}
              minTickGap={48}
            />
            <YAxis
              domain={domain}
              tickFormatter={(v) => formatValue(v, unit)}
              stroke="var(--color-text-muted)"
              fontSize={11}
              width={yAxisWidth}
            />
            <Tooltip
              labelFormatter={(ms) => new Date(ms).toLocaleString()}
              formatter={(v) => [formatValue(v, unit), seriesName]}
              contentStyle={{
                background: "var(--color-panel)",
                border: "1px solid var(--color-border)",
                fontSize: "12px",
              }}
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="var(--color-accent)"
              dot={false}
              strokeWidth={1.5}
              connectNulls={false}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      {gapCount > 0 && (
        <p className="note">
          {gapCount} sample{gapCount === 1 ? "" : "s"} in this window had no reading (sensor
          unavailable) and appear as gaps.
        </p>
      )}
    </>
  );
}
